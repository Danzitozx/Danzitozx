/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package com.package1.codigoaula;

/**
 *
 * @author okmen
 */
public class TestHomer {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        No testhomer = new No("");
        //1
        testhomer.inserir("Homer");
        testhomer.inserir("Marge");
        //2
        testhomer.remover("Homer");
        testhomer.remover("Marge");
        System.out.println(testhomer);
        
        //3
        testhomer.inserir("Homer");
        testhomer.inserir("Bart[0]");
        testhomer.inserir("Moll[1]");
        System.out.println(testhomer);
        
        //4
        testhomer.remover(ListaDuplamenteEncadeada);
        
        //5
        testhomer.inserir("Homer");
        testhomer.inserir("Bart");
        testhomer.inserir.inicio("Lisa");
        System.out.println(testhomer.lenght);
        
        //6
        testhomer.remover(ListaDuplamenteEncadeada);
        System.out.println(testhomer);
        
        //7
        testhomer.inserir("Homer");
        testhomer.inserir("Maggie");
        testhomer.inserir("Bart[0]");
        testhomer.inserir("Marge[1]");
        System.out.println(testhomer);
        testhomer.exibir("Lisa");
        
        //8
        testhomer.remover(ListaDuplamenteEncadeada);
        
        //9
        testhomer.inserir("Homer");
        testhomer.inserir("Bart");
        System.out.println(testhomer.lenght);
        
        //10
        testhomer.exibir("Marge");
        testhomer.exibir("Homer");
        testhomer.exibir("Bart");
        testhomer.exibir("Maggie");
        System.out.println(testhomer.lenght);
        
        //11
        testhomer.remover(ListaDuplamenteEncadeada);
        
        //12
        testhomer.inserir.inicio("Homer");
        testhomer.inserir.inicio("Bart");
        testhomer.inserir("Marge");
        testhomer.inserir("Maggie[1]");
        testhomer.inserir.inicio("Ned Flanders");
        testhomer.inserir.fim("Sr.Burns");
        System.out.println(testhomer);
        
        //13
        testhomer.remover.fim(ListaDuplamenteEncadeada);
        System.out.println(testhomer);
        
        //14
        testhomer.remover([1]);
        System.out.println(tethomer.lenght);
        
        //15
        testhomer.exibir("Marge");
        testhomer.exibir("Homer");
        testhomer.exibir("Bart");
        teshomer.exibir("Maggie");
        System.out.println(testhomer.lenght);
        
        //16
        testhomer.inicio.remover();
        System.out.println(testhomer.lenght);
        
        //17
        testhomer.exibir("Marge");
        testhomer.exibir("Homer");
        testhomer.exibir("Bart");
        testhomer.exibir("Maggie");
        System.out.println(testhomer.lenght);
        
        //18
        testhomer.remover(ListaDuplamenteEncadeada);

    }
}

